export class TestCase {
    input: number;
    output: string;
}
